#' labsimplex: Implementation of simplex optimization algorithms for
#' laboratory applications.
#'
#' @section labsimplex functions:
#' The labsimplex functions...
#'
#' @docType package
#' @name labsimplex
NULL
